module.exports = {
  mongoURI: "mongodb+srv://testing:admintest@cluster0-oysp4.mongodb.net/test",
  secretOrKey: "secret"
};
